import os,json

script_dir = os.path.dirname(os.path.realpath(__file__))

instruments = [
    "harp", "basedrum", "snare", "hat", "bass", "flute", "bell", "guitar", "chime",
    "xylophone", "iron_xylophone", "cow_bell", "didgeridoo", "bit", "banjo", "pling", "zombie", "skeleton", 
    "creeper", "dragon", "wither_skeleton", "piglin", "custom_head"
]

notes = list(range(25))

blockstates = {
    "variants": {}
}

for instrument in instruments:
    for note in notes:
        blockstate = f"instrument={instrument},note={note},powered=false"
    
        blockstates["variants"][blockstate] = {
            "model": "minecraft:block/note_block"
        }

for instrument in instruments:
    for note in notes:
        blockstate = f"instrument={instrument},note={note},powered=true"
        
        blockstates["variants"][blockstate] = {
            "model": "minecraft:block/note_block"
        }

with open(script_dir + "\\note_block_lol.json", "w") as f:
    json.dump(blockstates, f, indent=4)

print("note_block.json has been generated successfully.")